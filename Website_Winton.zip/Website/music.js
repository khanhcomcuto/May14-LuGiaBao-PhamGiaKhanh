/* Nhạc nền dùng chung cho 8 trang + phím tắt.
   Phím tắt: M = Phát/Tạm dừng, N = Tắt/Bật tiếng, + (hoặc =) = Tăng âm lượng, - = Giảm âm lượng.
   Trạng thái (đang phát, vị trí, âm lượng) được nhớ qua localStorage để nhạc liền mạch giữa các trang. */
(function () {
  var audio = document.getElementById("bg-music");
  var btn = document.getElementById("music-toggle");
  var vol = document.getElementById("music-volume");
  var status = document.getElementById("music-status");
  if (!audio || !btn || !vol) return;

  function load(key, fallback) {
    try { var v = localStorage.getItem(key); return v === null ? fallback : v; } catch (e) { return fallback; }
  }
  function save(key, value) {
    try { localStorage.setItem(key, value); } catch (e) {}
  }

  audio.volume = parseFloat(load("mlk_vol", "0.4"));
  vol.value = audio.volume;
  var wantPlay = load("mlk_play", "0") === "1";

  audio.addEventListener("loadedmetadata", function () {
    var t = parseFloat(load("mlk_time", "0"));
    if (t > 0 && t < audio.duration) audio.currentTime = t;
  });

  function render() {
    var playing = !audio.paused;
    btn.textContent = playing ? "Tạm dừng" : "Phát nhạc";
    btn.setAttribute("aria-pressed", playing ? "true" : "false");
    if (status) status.textContent = audio.muted ? "Đã tắt tiếng" : (playing ? "Đang phát" : "Đã dừng");
  }
  function play() {
    var p = audio.play();
    if (p && p.catch) p.catch(function () { if (status) status.textContent = "Nhấn để phát"; });
    save("mlk_play", "1");
  }
  function pause() { audio.pause(); save("mlk_play", "0"); }
  function toggle() { audio.paused ? play() : pause(); }
  function setVolume(v) {
    v = Math.max(0, Math.min(1, v));
    audio.volume = v; vol.value = v; save("mlk_vol", String(v));
  }

  btn.addEventListener("click", toggle);
  vol.addEventListener("input", function () { setVolume(parseFloat(vol.value)); });
  audio.addEventListener("play", render);
  audio.addEventListener("pause", render);
  audio.addEventListener("volumechange", render);
  setInterval(function () { if (!audio.paused) save("mlk_time", String(audio.currentTime)); }, 1000);
  window.addEventListener("beforeunload", function () { save("mlk_time", String(audio.currentTime)); });

  document.addEventListener("keydown", function (e) {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    var tag = (e.target.tagName || "").toLowerCase();
    if (tag === "input" && e.target.type !== "range") return;
    if (tag === "textarea") return;
    var k = e.key;
    if (k === "m" || k === "M") { e.preventDefault(); toggle(); }
    else if (k === "n" || k === "N") { e.preventDefault(); audio.muted = !audio.muted; render(); }
    else if (k === "+" || k === "=") { e.preventDefault(); setVolume(audio.volume + 0.1); }
    else if (k === "-" || k === "_") { e.preventDefault(); setVolume(audio.volume - 0.1); }
  });

  /* Trình duyệt chặn tự phát: nếu trang trước đang phát, tiếp tục ngay khi người dùng tương tác đầu tiên. */
  if (wantPlay) {
    var p = audio.play();
    if (p && p.catch) {
      p.catch(function () {
        var resume = function () {
          if (load("mlk_play", "0") === "1" && audio.paused) audio.play().catch(function () {});
          document.removeEventListener("pointerdown", resume);
          document.removeEventListener("keydown", resume);
        };
        document.addEventListener("pointerdown", resume);
        document.addEventListener("keydown", resume);
      });
    }
  }
  render();
})();
